// ▼ 開発環境のURL
//const API_BASE_URL = "https://linkcanvas-kdc7.onrender.com"; 

// ▼ 本番環境のURL
const API_BASE_URL = "https://linkcanvas-kdc7.onrender.com"; 

// デプロイ用のデータ作成時には本番URLに書き換える
export { API_BASE_URL };